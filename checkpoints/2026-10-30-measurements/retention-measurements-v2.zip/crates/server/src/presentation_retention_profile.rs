//! Root-lifetime profile, not a heap-size estimate. Run each workload in an
//! isolated test process. Linux RSS is supplementary and includes allocator
//! caching, fixture/archive growth and all other process allocations.
use super::*;
use crate::journal::{Action, Command};

fn drain(client: &mut Connection) {
    while client.messages.try_recv_frame().is_ok() {}
}

fn waits(service: &mut Service, count: usize, sequence: &mut usize) {
    let actor = ActorId(1);
    for _ in 0..count {
        *sequence += 1;
        service
            .engine
            .command(
                "retention-profile",
                "headless",
                actor,
                &format!("wait-{}", sequence),
                &service.engine.branch().clone(),
                Command::Act {
                    expected_boundary: service.engine.causal_boundary(actor).unwrap(),
                    action: Action::Wait,
                },
            )
            .unwrap();
    }
}

fn resident_kib() -> Option<usize> {
    let text = std::fs::read_to_string("/proc/self/status").ok()?;
    text.lines()
        .find(|line| line.starts_with("VmRSS:"))?
        .split_whitespace()
        .nth(1)?
        .parse()
        .ok()
}

fn roots(service: &Service) -> BTreeSet<usize> {
    service
        .clients
        .values()
        .flat_map(|client| &client.presentations.entries)
        .map(|issued| issued.boundary.retention_root())
        .collect()
}

fn report(service: &Service, watchers: usize, stage: &str) {
    let roots = roots(service);
    let rewind = service.engine.retained_boundary_roots();
    let slots: usize = service
        .clients
        .values()
        .map(|client| client.presentations.entries.len())
        .sum();
    let charts: usize = service
        .clients
        .values()
        .flat_map(|client| &client.presentations.entries)
        .map(|issued| issued.charts.len())
        .sum();
    println!(
        "RETENTION_PROFILE {}",
        serde_json::json!({
            "format": "presentation-retention-roots-v1",
            "watchers": watchers,
            "stage": stage,
            "attached": service.clients.len(),
            "capability_slots": slots,
            "advertised_chart_rows": charts,
            "issued_boundary_roots": roots.len(),
            "rewind_boundary_roots": rewind.len(),
            "issued_roots_outside_rewind": roots.difference(&rewind).count(),
            "union_boundary_roots": roots.union(&rewind).count(),
            "archive_records": service.engine.profile_counts().0,
            "process_resident_kib": resident_kib(),
        })
    );
}

fn profile(watchers: usize) {
    // The explicit 1 MiB frame ceiling permits the host's existing 128-client
    // maximum. This is not a claim that every default-output configuration does.
    let limits = crate::OutboundLimits {
        frame_bytes: 1024 * 1024,
        ..Default::default()
    };
    assert!(limits.connection_limit() >= watchers);
    let mut service = Service::with_outbound_limits(
        Engine::memory(crate::Scenario::two_room(42)).unwrap(),
        limits,
    )
    .unwrap();
    let mut clients = Vec::new();
    for i in 0..watchers {
        let mut client = service
            .connect(
                &Account {
                    role: AccessRole::Spectator,
                    user: format!("reader-{i}"),
                    token: "test-only".into(),
                    actors: BTreeSet::from([ActorId(1)]),
                },
                "headless".into(),
            )
            .unwrap();
        service.handle(
            client.id,
            "attach".into(),
            Request::Attach { actor: ActorId(1) },
        );
        drain(&mut client);
        clients.push(client);
    }
    report(&service, watchers, "attached_same_boundary");
    assert_eq!(roots(&service).len(), 1);
    let mut sequence = 0;
    for client in &mut clients {
        for _ in 0..RETAINED_PRESENTATIONS {
            service.observe(client.id).unwrap();
            drain(client);
        }
        assert_eq!(
            service.clients[&client.id].presentations.entries.len(),
            RETAINED_PRESENTATIONS
        );
    }
    report(&service, watchers, "full_slots_same_boundary");
    assert_eq!(
        roots(&service).len(),
        1,
        "slots are references, not whole Game copies"
    );
    let frozen_base = service.clients[&clients[0].id]
        .presentations
        .entries
        .front()
        .unwrap()
        .base
        .clone();
    let frozen_state = {
        let issued = service
            .issued_presentation(clients[0].id, &frozen_base)
            .unwrap();
        service
            .engine
            .state_at(&issued.boundary, ActorId(1), frozen_base.revision)
            .unwrap()
    };
    waits(&mut service, 300, &mut sequence);
    {
        let issued = service
            .issued_presentation(clients[0].id, &frozen_base)
            .unwrap();
        assert_eq!(
            service
                .engine
                .state_at(&issued.boundary, ActorId(1), frozen_base.revision)
                .unwrap(),
            frozen_state
        );
    }
    drop(frozen_state);
    report(&service, watchers, "changed_without_observe");
    assert_eq!(
        roots(&service)
            .difference(&service.engine.retained_boundary_roots())
            .count(),
        1
    );
    // Each spectator now pins two newly committed and mutually distinct states.
    // Old repeated slots still point at one shared pre-change state.
    for _ in 0..2 {
        for client in &mut clients {
            waits(&mut service, 1, &mut sequence);
            service.observe(client.id).unwrap();
            drain(client);
        }
    }
    report(&service, watchers, "staggered_two_boundaries_each");
    assert_eq!(roots(&service).len(), 1 + 2 * watchers);
    let probes: Vec<_> = service
        .clients
        .values()
        .flat_map(|client| &client.presentations.entries)
        .map(|issued| issued.boundary.retention_probe())
        .collect();
    waits(&mut service, 300, &mut sequence);
    report(&service, watchers, "staggered_outside_rewind");
    assert_eq!(
        roots(&service)
            .intersection(&service.engine.retained_boundary_roots())
            .count(),
        0
    );
    assert!(probes.iter().all(|probe| probe.alive()));
    for client in &clients {
        service.disconnect(client.id);
    }
    clients.clear();
    assert!(service.clients.is_empty());
    assert!(
        probes.iter().all(|probe| !probe.alive()),
        "disconnect releases every extra boundary root"
    );
    // Weak probes retain the Arc allocation shell until dropped. They must not
    // contaminate even the supplementary post-disconnect RSS sample.
    drop(probes);
    report(&service, watchers, "disconnected");
}

#[test]
fn one_watcher_retention_profile() {
    profile(1);
}

#[test]
fn sixteen_watchers_retention_profile() {
    profile(16);
}

#[test]
fn maximum_watchers_retention_profile() {
    profile(128);
}
