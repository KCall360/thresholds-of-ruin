# Presentation retention root profile

Prepared October 30, 2026 on a3853eaa391730ecbd06bdb03dd40c3994a1927f (PR 209 corrected source). This source excludes PR 210 body reuse and checkpoint-classification work. Production behavior is unchanged: only test-gated identity/Weak probes and Service workloads are added. No build or runtime measurement has yet been completed.

## Existing evidence and question

The existing test proves older full StateViews are released, capabilities cap at 32, reset invalidates old capabilities and rejected output grants no authority. A source-backed plan already proposed 1/16/128 watchers; there is no saved measured retention result. Issued capabilities hold Arc<Boundary>, which shares current rewind-owned Game roots. Game uses mixed COW/shared pages and separately owned collections. Multiplying slot count by whole Game size is invalid.

## Probe

For each 1/16/128-watcher Service workload, record admitted capability slots, chart-summary rows, distinct issued Arc<Boundary> identities, current engine rewind identities, union, and set difference (extra roots pinned solely beyond rewind). Lifetime probes use Weak without incrementing strong counts. All data is backend test-only and never serialized to clients, persisted or used in gameplay decisions.

Stages: common initial state; 32 repeated observations per watcher without state change; 300 authoritative Wait actions without observations; two interleaved changes/observations per watcher; 300 more changes to move all issued states beyond rewind; disconnect every watcher. Frozen state materialization is checked across the first 300 changes. Weak probes must show every extra root dies after disconnect. Probes are dropped before the final RSS sample.

The workload configures a 1 MiB frame ceiling under the existing 256 MiB aggregate output budget to permit all 128 supported connections. Defaults permit only 16 connections; the 128 row is explicitly a supported alternate-output configuration, not default gameplay. Each output queue is drained immediately, isolating capability retention from queued-frame leases. Stationary waits are cheap and reproducible but do not represent mutation-dense world memory costs.

## Measurement boundaries

Distinct roots are exact lifetime counts, not allocation bytes. Linux /proc/self/status VmRSS is only supplementary whole-process RSS; it includes allocator caching, archive growth, fixture allocations and code pages. It is neither unique retained heap bytes nor a before/after optimization. Run each method in a separate one-test process, --nocapture, --test-threads=1; record compiler/source/binary identity and process fingerprint. Non-Linux RSS is null, not zero.

No cap reduction or payload redesign is justified yet. Existing hard limits already bound slots by the admitted connection count (32 * 16 default; 32 * 128 maximum configured). The profile will determine how many distinct historical roots those references actually pin. A follow-up mutation-dense fixture plus allocation-aware tooling is required before memory-savings claims or policy changes.

## Build coordination

No independent Cargo target. Checkpoint worker currently owns the warm target; PR 210 driver fix takes priority. Await explicit sequential ownership handoff, preserve binaries and compare/refresh changed source mtimes per repository testing instructions.

The mutation driver calls the ordinary Engine command API directly while the Service owns attached viewers; it does not submit spectator actions or enqueue each action's outbound events. This isolates historical boundary ownership, not transport throughput or end-to-end multi-client simulation. Per-observer output is admitted and drained through the real Service observation path.
