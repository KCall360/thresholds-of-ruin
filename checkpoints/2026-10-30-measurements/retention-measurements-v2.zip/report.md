# Retained presentation root measurements

## Result

Three isolated debug-profile workloads and both existing presentation-history tests pass. Source remains exactly matched to the compile receipt. Production behavior is unchanged; instrumentation is test-only.

| Viewers | Slots at capacity | Roots for repeated unchanged observations | Extra roots after two staggered changes each and aging beyond rewind | Extra roots after disconnect |
| --- | ---: | ---: | ---: | ---: |
| 1 | 32 | 1 | 3 | 0 |
| 16 | 512 | 1 | 33 | 0 |
| 128 | 4,096 | 1 | 257 | 0 |

The staggered workload also retains the original shared root, hence 1 + 2 × viewers. Each root is a distinct Arc<Boundary>, not a whole unique allocation graph. Current engine rewind retains 128 roots in these ordinary-Wait samples; presentation roots can outlive that window, as expected. Weak probes prove every extra root is destroyed on disconnect. An old admitted state materializes identically after 300 later actions.

## Boundaries and interpretation

Default output settings admit 16 connections; the 128 sample explicitly uses the supported 1 MiB-frame configuration under a 256 MiB aggregate output budget. The primitive two-room fixture uses stationary Wait actions through Engine plus real Service observation/admission/drain, not a full transport or mutation-dense world workload. It measures ownership and lifetime, not real-world heap savings, latency or throughput.

In the 128-viewer process, RSS was 41,860 KiB after attachment, 46,248 KiB at full unchanged-state slots, 50,428 KiB after aged staggered states and 50,492 KiB after disconnect. RSS includes allocator caching, code/fixture/archive and other allocations. It did not fall despite proven root destruction. It therefore does not quantify uniquely retained heap bytes or justify a memory-savings claim. Other process RSS values vary and are retained in results.json, not used as a cross-process comparison.

A new retention cap or capability expiry change is not justified by these results. Existing slots are bounded, unchanged states share one root and disconnect cleanup works. Next, if byte-level sizing is needed, use allocation-aware paired measurements on mutation-dense representative worlds, preserving explicit page/annotation expiry and privacy. Never estimate memory as slots multiplied by full Game size. No cap reduction, wire/save/rules change or performance optimization was made.

## Evidence

Base a3853eaa391730ecbd06bdb03dd40c3994a1927f, before PR 210 and checkpoint-classification changes. The result does not qualify those branches. Compile preflight passed; first filtered compile/run took 503.85 seconds mostly compiling, while the test itself took 0.02 seconds. Isolated workload runtimes were 0.028, 0.126 and 0.923 seconds, diagnostic context only, not benchmark speedup claims.

Binary SHA-256 360eafa2254b1e6bb1fa322666d102c079b2448c1d14dee29d1183973ff7cefd. Full input identities, source guard, logs and rows are retained beside this report. Warm target returned to checkpoint owner; copied binary is protected. No release run or full CI, no published PR.
