# Physical discovery growth: results and design recommendation

## Measured baseline

All 54 discovery tests passed, including the three new focused tests. The optional 1,024 expansion passed after the mandatory small suite completed in 0.12 seconds. Its separate process took 1.03 seconds including repeated 128-fact cases. These are debug diagnostic runtimes, not release speedup measurements.

| Facts acquired | Actual vector clones | Rows copied, ascending and reverse | Ascending shifted rows | Reverse-ID stress shifted rows |
| --- | ---: | ---: | ---: | ---: |
| 16 | 16 | 239 | 0 | 15 |
| 128 | 128 | 9,815 | 0 | 8,023 |
| 1,024 | 1,024 | 538,007 | 0 | 523,671 |

Every forward row ended with exactly the requested number of independently encountered attempted facts. The default 16/128 suite and extended repeat returned identical 128 rows. Reentry created/copied/inserted zero discovery-vector rows and consumed no new RNG; readonly queries and encoded checkpoint/restore preserved exact knowledge and observations. Forward candidate scans were 18/130/1,026 and visible-cell visits 4,888/51,032/420,184; reentry still scans changed viewpoints, but does not copy the receipt vector. These different units must not be combined.

The ascending baseline establishes full-vector copy growth without reverse insertion. The reverse-ID arrangement is intentionally an insertion-order stress control, not a claim about normal Rogue generation. Receipts came from normal movement/passive discovery, not an injected sorted vector. The narrow single-chamber corridor and 32 retained snapshots isolate this owner, not a full-game latency or real generated-dungeon workload.

## Recommendation: retain the vector for now; do not restructure solely from counts

A quadratic copied-row component is demonstrated. A significant end-to-end or release-time bottleneck is not: even the 1,024-fact diagnostic remains cheap in this fixture. A persistent/chunked owner would add ordering, equality and serialization complexity. The current evidence does not yet establish a sufficiently clear maintainability/performance tradeoff to replace the small vector. Preserve the instrumentation and immutable baseline, and obtain a matched release attribution on a representative long-lived actor before choosing the structural change. This is a negative implementation decision, not dismissal of the measured scaling concern.

## Smallest candidate if release attribution warrants it

Use one private ordered-facts owner with a small-vector representation through 64 facts and COW sorted chunks above that threshold. No external container dependency, no global cache and no lifetime/forgetting policy. Keep scalar len and use binary search over chunk endpoint keys, then within one chunk. Facts are append/update-only by identity; no deletion/merge policy is required. A full chunk splits locally. Clone the outer vector of shared chunk handles, copying only the touched chunk when it is shared.

This is a candidate, not implemented code or a predicted measured speedup. A 64-row threshold is a starting experiment, not a tuned optimum. Small saves should retain the existing single-vector allocation and behavior. Large saves add an outer handle array and per-chunk Arc/header/capacity overhead; fewer copied fact rows do not automatically mean fewer bytes or lower time. Count handle copies, fact-row copies, shifts and allocation events independently. Compare 16/128/1,024 on the same fixture/profile/compiler and retain reverse stress separately. The baseline is 239/9,815/538,007 copied fact rows; candidate counts do not exist yet.

## Required invariants and independent witnesses

- Canonical order remains DiscoveryTarget order (Door, Trap, Guise, then ID); stable identity and first-eye/adjacent attempts are unchanged. No pointer identity, chunk layout or hash-map iteration influences gameplay or RNG.
- Wire-independent save shape remains the exact ordered flat array of DiscoveryFact objects. Do not serialize representation tags, chunk boundaries, capacity or cached keys. Strict max 262,144 facts, duplicate/order/alias rejection and impossible-flag checks remain intact.
- Equality must compare logical ordered facts, not runtime chunk boundaries: identical facts can arise through different insertion orders or flatten/repack restoration. Deserialization may pack deterministic chunks, but it must not alter logical equality/replay.
- Differential oracle: preserve the original Vec implementation as a test-local reference, feed identical valid updates including idempotent, ascending, reverse and mixed Door/Trap/Guise operations, and compare complete flattened facts after every operation. Test 63/64/65 and split-edge keys plus exact cap rejection without mutation. Baseline flat-array bytes and independently specified malformed fixtures must remain unchanged.
- Replay/public observations: run the ordinary growth/reentry/readonly/encoded-restore witnesses plus existing passive/paid discovery, visibility/privacy, guise, pause/recovery and save/restart owners. Match RNG, attempts, presence/family knowledge and complete observations, not only fact counts.
- If a candidate is pursued, first add representation-independent expected counters/shape controls, verify intended baseline failure only for the requested work bound, then implement. Keep actual runtime failures distinct from deliberate first-red evidence. Required release checks and hosted qualification are not waived by this diagnostic.

## Evidence and state

Base a3853eaa391730ecbd06bdb03dd40c3994a1927f; no new production semantics. The three changed paths contain only test-gated instrumentation/registration/workloads. Production DiscoveryKnowledge retains its derived Clone. Existing retention conclusion remains unchanged: no new cap.

Binary 71b2a48d6b1d966758c2eb1990d89dfb1f53e54822e68e975e11dc7bee9df53a; complete source input guard passes. Mandatory small-suite receipt, raw output, explicit optional environment and full 54-test log are archived. No release run, PR publication or candidate structural result. Shared target released; no pending build.
