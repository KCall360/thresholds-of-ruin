# Physical discovery growth profile, prepared October 30

Base a3853eaa. Work is separate from the qualified retention source. No production structure, lifetime cap, rules or save-format change. DiscoveryKnowledge keeps its production derived Clone; only cfg(test) substitutes identical Vec cloning with copy counters. Insert counters observe actual inserted/shifted rows after admission guards. Existing DISCOVERY_WORK counts remain distinct.

One configured ordinary actor traverses a narrow chamber corridor beside (not onto) 16 or 128 concealed high-DC traps. First-eye and adjacent receipts arise through the ordinary Game action/discovery path, not forged knowledge. Explicit seed42. Ascending feature order is the baseline; reversed-ID assignment is a labelled stress control. Thirty-two prior Game snapshots are retained, modelling historical state ownership; this is not a claim of a full server or actual generated Rogue layout. Candidate sight is bounded to16 cells and should grow receipts incrementally.

Record actual final facts, actual Vec clones/copied rows, successful insertions/shifted rows, candidate scans and sight rows for forward movement and reentry. Reentry/read-only/encoded checkpoint-restore witnesses preserve RNG and exact knowledge/observations. A small independent counter test distinguishes Arc handle cloning, deep detachment, insertion and idempotent update.

The 1024 expansion is compiled but opt-in only via TOR_DISCOVERY_PROFILE_EXTRA_1024=1 on the mandatory128 test. Run it only if measured128 runtime is cheap and retain the environment in its receipt. It does not skip or replace any mandatory test. No elapsed-time optimization claim; targeted release comparisons only if a later change is justified.

No Cargo call yet. Await checkpoint owner's release-storage handoff, then standard source-hash/mtime guard, simulation-lib preflight and focused tests. Copy resulting binary before returning the target. Toolchain uses existing .local/toolchain/{cargo,rustup}; no installation.
