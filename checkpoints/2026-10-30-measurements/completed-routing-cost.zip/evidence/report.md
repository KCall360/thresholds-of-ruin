# Routing operation attribution (completed optimized diagnostic)

Base: a3853eaa391730ecbd06bdb03dd40c3994a1927f, same base as discovery profile, not fresh current main. Only a test module registration and new diagnostic test file differ. No production algorithm/schema/cap changes.

## Workload and metric meanings

One ordinary actor physically walks to the end and back through single-cell-wide chambers of 24, 96 and 384 traversable cells. Navigation refreshes at each ordinary movement boundary. No injected navigation graph; setup verifies each actor location. Eight destinations at integer eighths of the corridor are queried in ascending and descending order. Compare eight fresh searches with the already-existing shared search API, followed by a repeat pass over the same shared search. This is not a candidate optimization or production before/after measurement.

`route_searches` is the existing actual search-start counter. Settled locations, discovered `(location, frame)` nodes and predecessor rows are actual map lengths; fresh values are sums across separate queries. On this unique, frame-zero corridor, logical settled counts also account for expanded locations. They are not allocator calls, heap bytes, RSS, queue-pop counts, or a general expansion counter for arbitrary rotated graphs. Returned route lengths equal actual predecessor links traversed/pushed during reconstruction by the source loop. Each repeat reconstructs its owned route vector again, even when no search maps grow. No wall-clock or end-to-end speed claim.

## Equality witnesses

Each route must equal an independently constructed east-only sequence with every intermediate destination. Compare with the retained fresh reference implementation outside counted windows. Whole Game and public observation equality before/after planning verifies read-only behavior. Encode both checkpoint and SharedState, decode/restore, and check navigation, rules RNG, public observation and sampled exact routes. Existing permanent `travel::tests::shared_search_matches_fresh_routes_across_target_orders_and_frames` separately covers directed cycles, rotations, ties and unreachable targets. The simple physical corridor is not a substitute for that stress witness.

## Interpretation boundary

AI already shares one search across visible target queries (`ai.rs:324`). This profile tests that reuse rather than claiming a new speedup. Flee uses different candidate origins/frames (`ai.rs:724`), which cannot naively reuse one source-rooted tree. Scalar route-length queries could avoid vector construction where callers immediately discard routes, but must return the hop count of the existing minimum-duration, stable-tie chosen route—not replace it with a shortest-hop metric. No practical timing attribution currently justifies that new API or cached hop-count state. Any stored hop count adds per-node memory and must be justified against tiny ordinary saves. No structural optimization is proposed from operation counts alone.

## Results

Both target orders produced identical counts:

| Cells | Fresh / shared starts | Fresh / shared settled locations | Fresh / shared discovered nodes | Fresh / shared predecessor rows | Reconstruction links per pass |
|---:|---:|---:|---:|---:|---:|
| 24 | 8 / 1 | 108 / 24 | 115 / 24 | 107 / 23 | 100 |
| 96 | 8 / 1 | 432 / 96 | 439 / 96 | 431 / 95 | 424 |
| 384 | 8 / 1 | 1728 / 384 | 1735 / 384 | 1727 / 383 | 1720 |

Every repeat pass added zero search starts and zero search-map rows, while reconstructing the same number of links. Existing reuse is effective. This is baseline fresh versus baseline shared operation attribution, not an implemented candidate comparison. A query result still owns its Vec; memory and pure reconstruction time remain unmeasured. No routing optimization is recommended on this evidence alone.

## Validation / provenance

Release preflight (`cargo check --release --locked -p tor-simulation --lib --tests`) passed in 40.56 seconds. Release focused diagnostic passed (one test, six size/order cases; 0.10 seconds reported runtime); compile/test command took 387.21 seconds, not a gameplay timing. Protected binary then passed all 11 `travel::` tests, including existing directed-frame/tie/unreachable reference witness (1.80 seconds reported runtime). Exact checked source inputs remained unchanged for each command. No debug rerun, full suite, server/process/CI qualification or end-to-end benchmark was performed; test-only profiling changes do not alter production semantics.

Protected optimized binary SHA256: `6258a0348e4b45c66c2384d67dece73f1ebccdf3939bbe388983e6c41a0f9e8c`.
Source identities and command/environment/toolchain receipts are in `release/preflight/`, `release/focused/`, and `all-travel-receipt.json`. Runtime output is `all-travel.log`; structured operation counts are `results.json`. No Rust input was edited during any build/test.
