//! Operation attribution only: ordinary exploration, no fabricated navigation.
use super::*;
use std::num::NonZeroU64;
use tor_world::{Extent, Region, RegionId, World};

fn at(x: i32) -> Location {
    Location {
        region: RegionId(1),
        position: Position { x, y: 0, z: 0 },
    }
}
fn expected(x: i32) -> Vec<TravelStep> {
    (1..=x)
        .map(|x| TravelStep {
            direction: Direction::East,
            destination: at(x),
        })
        .collect()
}
fn profile(cells: i32) {
    let mut world = World::new(vec![], vec![]).unwrap();
    world
        .add_chamber(Region {
            id: RegionId(1),
            name: "Routing attribution corridor".into(),
            bounds: Extent::new(cells, 1, 1).unwrap(),
        })
        .unwrap();
    let mut game = Game::new(world, 42, crate::test_creatures::content());
    let actor = game
        .spawn_actor(at(0), NonZeroU64::new(100).unwrap())
        .unwrap();
    game.refresh_navigation();
    for x in 1..cells {
        game.act(actor, crate::Action::Move(Direction::East))
            .unwrap();
        assert_eq!(game.actors[&actor].location, at(x));
        game.refresh_navigation();
    }
    for x in (0..cells - 1).rev() {
        game.act(actor, crate::Action::Move(Direction::West))
            .unwrap();
        assert_eq!(game.actors[&actor].location, at(x));
        game.refresh_navigation();
    }
    let before = game.clone();
    let observed = game.observe(actor).unwrap();
    for reverse in [false, true] {
        let mut targets: Vec<_> = (1..=8).map(|n| (cells - 1) * n / 8).collect();
        if reverse {
            targets.reverse();
        }
        let mut fresh_settled = 0;
        let mut fresh_discovered = 0;
        let mut fresh_previous = 0;
        let mut links = 0;
        let starts = crate::diagnostics::work_counts().route_searches;
        for &x in &targets {
            let mut search = game.route_search(actor).unwrap();
            let route = search.route(at(x)).unwrap();
            assert_eq!(route, expected(x));
            links += route.len();
            fresh_settled += search.settled.len();
            fresh_discovered += search.distances.len();
            fresh_previous += search.previous.len();
        }
        let fresh_starts = crate::diagnostics::work_counts().route_searches - starts;
        assert_eq!(fresh_starts, 8);
        let starts = crate::diagnostics::work_counts().route_searches;
        let mut shared = game.route_search(actor).unwrap();
        for &x in &targets {
            assert_eq!(shared.route(at(x)).unwrap(), expected(x));
        }
        let sizes = (
            shared.settled.len(),
            shared.distances.len(),
            shared.previous.len(),
        );
        let shared_starts = crate::diagnostics::work_counts().route_searches - starts;
        assert_eq!(shared_starts, 1);
        for &x in &targets {
            assert_eq!(shared.route(at(x)).unwrap(), expected(x));
        }
        assert_eq!(
            sizes,
            (
                shared.settled.len(),
                shared.distances.len(),
                shared.previous.len()
            )
        );
        assert_eq!(crate::diagnostics::work_counts().route_searches - starts, 1);
        assert_eq!(sizes.0, cells as usize);
        println!(
            "ROUTING_COST {}",
            serde_json::json!({"cells": cells, "reverse":reverse, "queries":8, "fresh_search_starts":fresh_starts, "fresh_settled_locations_sum":fresh_settled, "fresh_discovered_nodes_sum":fresh_discovered, "fresh_predecessor_rows_sum":fresh_previous, "shared_search_starts":shared_starts, "shared_settled_locations":sizes.0, "shared_discovered_nodes":sizes.1, "shared_predecessor_rows":sizes.2, "reconstructed_links_per_pass":links, "repeat_additional_search_starts":0, "repeat_additional_state_rows":0})
        );
        for &x in &targets {
            assert_eq!(
                game.travel_route(actor, at(x)),
                game.reference_travel_route(actor, at(x))
            );
        }
    }
    assert_eq!(game, before);
    assert_eq!(game.observe(actor).unwrap(), observed);
    let mut shared = crate::checkpoint::SharedState::default();
    let saved = game.checkpoint(&mut shared);
    let saved = serde_json::from_slice(&serde_json::to_vec(&saved).unwrap()).unwrap();
    let shared = serde_json::from_slice(&serde_json::to_vec(&shared).unwrap()).unwrap();
    let restored = Game::restore_checkpoint(saved, &shared, game.content().clone()).unwrap();
    assert_eq!(restored.observe(actor).unwrap(), observed);
    assert_eq!(restored.rules_rng, game.rules_rng);
    assert_eq!(restored.navigation, game.navigation);
    for x in [1, cells / 2, cells - 1] {
        assert_eq!(restored.travel_route(actor, at(x)).unwrap(), expected(x));
    }
}
#[test]
fn ordinary_exploration_shared_routing_attribution() {
    for cells in [24, 96, 384] {
        profile(cells);
    }
}
