# Optimized baseline timing attribution, prepared

One release build, no structural optimization. Same ordinary growth fixtures and exact counter/semantic witnesses. Paired process samples switch only the new Vec counters on/off; both retain the test-only toggle branch and the pre-existing discovery-scan diagnostics. Therefore this is a relative counter-update overhead check, not perfect instrumentation-free production timing.

A third control removes concealed features from the same-length corridor, retaining the actor, geometry, movement count and saved-snapshot loop. It measures the combined contribution of discovery/cue handling, not pure vector-copy time. It has zero expected facts and never substitutes for the ordinary cue-bearing tests.

Forward window includes initial discovery reconciliation, Game snapshot retention, ordinary movement and position assertions. Reentry window includes ordinary movement and position assertions. Fixture construction, output serialization and readonly/encoded-replay validation are outside both windows. Setup and scopes match between samples; first-pass initial reconciliation is included in both counters and timing.

After one warmup per mode, run seven measured paired processes per size/order with alternating mode order. Report median and observed range, per-phase and per movement normalization (the forward phase additionally includes one initialization pass), exact counters and platform/compiler/source identity. No p95 precision, pure-copy attribution, end-to-end latency or speedup claim. Select 1024 only because earlier debug expansion took approximately 1 second. No other local compilation or benchmark runs during measured processes; coordinate target release as needed.
