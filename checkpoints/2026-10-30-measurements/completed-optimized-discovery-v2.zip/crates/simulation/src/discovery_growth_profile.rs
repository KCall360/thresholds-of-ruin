//! Physical discovery history, independent of journal length. These fixtures
//! acquire receipts through normal passive discovery and ordinary movement.
use super::*;
use std::collections::VecDeque;

fn vector_delta(before: DiscoveryVectorWork) -> DiscoveryVectorWork {
    let after = DISCOVERY_VECTOR_WORK.with(|count| count.get());
    DiscoveryVectorWork {
        clones: after.clones - before.clones,
        copied_rows: after.copied_rows - before.copied_rows,
        insertions: after.insertions - before.insertions,
        shifted_rows: after.shifted_rows - before.shifted_rows,
    }
}

#[test]
fn vector_counters_distinguish_shared_handles_detach_and_insert_shifts() {
    DISCOVERY_VECTOR_ENABLED.with(|enabled| enabled.set(true));
    let mut initial = DiscoveryKnowledge::default();
    initial
        .mark_attempt(DiscoveryTarget::Trap(10), true, false)
        .unwrap();
    initial
        .mark_attempt(DiscoveryTarget::Trap(30), true, false)
        .unwrap();
    let original = Shared::new(initial);
    let before = DISCOVERY_VECTOR_WORK.with(|count| count.get());
    let mut candidate = original.clone();
    assert_eq!(vector_delta(before), DiscoveryVectorWork::default());
    candidate
        .mark_attempt(DiscoveryTarget::Trap(20), true, false)
        .unwrap();
    assert_eq!(
        vector_delta(before),
        DiscoveryVectorWork {
            clones: 1,
            copied_rows: 2,
            insertions: 1,
            shifted_rows: 1,
        }
    );
    candidate
        .mark_attempt(DiscoveryTarget::Trap(20), true, false)
        .unwrap();
    assert_eq!(
        vector_delta(before),
        DiscoveryVectorWork {
            clones: 1,
            copied_rows: 2,
            insertions: 1,
            shifted_rows: 1,
        }
    );
    assert_eq!(original.0.len(), 2);
    assert_eq!(candidate.0.len(), 3);
    assert!(candidate.valid());
}

fn corridor(facts: usize, reversed: bool, cues: bool) -> Game {
    let content = fixture(&[], &[]).content().clone();
    let mut world = tor_world::World::new(vec![], vec![]).unwrap();
    world
        .add_chamber(tor_world::Region {
            id: tor_world::RegionId(1),
            name: "Discovery growth corridor".into(),
            bounds: tor_world::Extent::new(i32::try_from(facts).unwrap() + 4, 4, 1).unwrap(),
        })
        .unwrap();
    let mut game = Game::new(world, 42, content);
    assert_eq!(
        spawn(&mut game, "fixture_perception_owner", at(1, 1, 1)),
        OWNER
    );
    for position in 0..if cues { facts } else { 0 } {
        let ordinal = if reversed {
            facts - position
        } else {
            position + 1
        };
        // Traps are beside the walking lane, never entered. A high DC retains
        // failed first-eye and adjacent attempts without exposing their family.
        trap(
            &mut game,
            ordinal as u64,
            at(1, position as i32 + 2, 2),
            100,
        );
    }
    game
}

fn report(
    game: &Game,
    facts: usize,
    reversed: bool,
    stage: &str,
    vector: DiscoveryVectorWork,
    scans: (usize, usize),
    snapshots: usize,
    counters_enabled: bool,
    cues: bool,
    elapsed: std::time::Duration,
) {
    println!(
        "DISCOVERY_GROWTH {}",
        serde_json::json!({
            "format":"physical-discovery-growth-v2", "facts":facts,
            "counters_enabled":counters_enabled, "concealed_cues":cues,
            "elapsed_ns":elapsed.as_nanos(), "movement_actions":facts + 1,
            "includes_initial_discovery":stage == "forward",
            "order":if reversed {"reverse-id-stress"} else {"ascending-id"},
            "stage":stage, "retained_snapshots":snapshots,
            "actual_facts":game.actors[&OWNER].discovery.0.len(),
            "attempted_facts":attempts(game, OWNER),
            "vector_clones":vector.clones, "copied_rows":vector.copied_rows,
            "insertions":vector.insertions, "shifted_rows":vector.shifted_rows,
            "candidate_scans":scans.0, "sight_cell_rows":scans.1,
        })
    );
}

fn profile(facts: usize, reversed: bool) {
    let counters_enabled = std::env::var("TOR_DISCOVERY_PROFILE_COUNTERS").as_deref() != Ok("0");
    let cues = std::env::var("TOR_DISCOVERY_PROFILE_NO_CUES").as_deref() != Ok("1");
    DISCOVERY_VECTOR_ENABLED.with(|enabled| enabled.set(counters_enabled));
    let mut game = corridor(facts, reversed, cues);
    let expected_facts = if cues { facts } else { 0 };
    let mut snapshots = VecDeque::new();
    let before = DISCOVERY_VECTOR_WORK.with(|count| count.get());
    let scans = DISCOVERY_WORK.with(|count| count.get());
    let started = std::time::Instant::now();
    game.initialize_discovery().unwrap();
    for x in 2..=facts + 2 {
        snapshots.push_back(game.clone());
        while snapshots.len() > 32 {
            snapshots.pop_front();
        }
        game.act(OWNER, crate::Action::Move(Direction::East))
            .unwrap();
        assert_eq!(game.actors[&OWNER].location, at(1, x as i32, 1));
    }
    let forward_elapsed = started.elapsed();
    let forward = vector_delta(before);
    let after_scans = DISCOVERY_WORK.with(|count| count.get());
    report(
        &game,
        facts,
        reversed,
        "forward",
        forward,
        (after_scans.0 - scans.0, after_scans.1 - scans.1),
        snapshots.len(),
        counters_enabled,
        cues,
        forward_elapsed,
    );
    assert_eq!(game.actors[&OWNER].discovery.0.len(), expected_facts);
    assert_eq!(attempts(&game, OWNER), expected_facts);
    assert_eq!(
        forward.insertions,
        if counters_enabled { expected_facts } else { 0 }
    );
    assert!(game.actors[&OWNER].discovery.valid());
    assert!(game.actors[&OWNER]
        .discovery
        .0
        .iter()
        .all(|fact| fact.attempted && fact.adjacent_attempted && !fact.presence && !fact.family));
    if !reversed {
        assert_eq!(forward.shifted_rows, 0);
    }
    let knowledge = game.actors[&OWNER].discovery.clone();
    let rng = game.rules_rng;
    let before = DISCOVERY_VECTOR_WORK.with(|count| count.get());
    let scans = DISCOVERY_WORK.with(|count| count.get());
    let started = std::time::Instant::now();
    for x in (1..=facts + 1).rev() {
        game.act(OWNER, crate::Action::Move(Direction::West))
            .unwrap();
        assert_eq!(game.actors[&OWNER].location, at(1, x as i32, 1));
    }
    let reentry_elapsed = started.elapsed();
    let reentry = vector_delta(before);
    let after_scans = DISCOVERY_WORK.with(|count| count.get());
    report(
        &game,
        facts,
        reversed,
        "reentry",
        reentry,
        (after_scans.0 - scans.0, after_scans.1 - scans.1),
        snapshots.len(),
        counters_enabled,
        cues,
        reentry_elapsed,
    );
    assert_eq!(reentry.insertions, 0);
    assert_eq!(reentry.copied_rows, 0);
    assert_eq!(game.rules_rng, rng);
    assert_eq!(game.actors[&OWNER].discovery, knowledge);
    let before_reads = game.clone();
    for _ in 0..3 {
        game.observe(OWNER).unwrap();
        game.scene(OWNER).unwrap();
    }
    assert_eq!(game.rules_rng, rng);
    assert_eq!(game.actors[&OWNER].discovery, knowledge);
    assert_eq!(game, before_reads);
    let observed = game.observe(OWNER).unwrap();
    let mut restored = checkpoint(&game);
    let restore_rng = restored.rules_rng;
    restored.reconcile_passive_discovery().unwrap();
    assert_eq!(restored.rules_rng, restore_rng);
    assert_eq!(restored.actors[&OWNER].discovery, knowledge);
    assert_eq!(restored.observe(OWNER).unwrap(), observed);
}

#[test]
fn sixteen_facts_ordinary_discovery_growth() {
    for reversed in [false, true] {
        profile(16, reversed);
    }
}

#[test]
fn one_hundred_twenty_eight_facts_ordinary_discovery_growth() {
    for reversed in [false, true] {
        profile(128, reversed);
    }
    // Explicit optional diagnostic expansion, never a substitute for the
    // mandatory small workload above. Record this environment in run receipts.
    if std::env::var("TOR_DISCOVERY_PROFILE_EXTRA_1024").as_deref() == Ok("1") {
        for reversed in [false, true] {
            profile(1024, reversed);
        }
    }
}
