# Completed optimized discovery checkpoint

This archive is the timing-instrumented source and its own exact release evidence. The authoritative identities are optimized-source-manifest.json and release/focused/inputs-after.json. All sampled processes use the protected binary identified in optimized-timing-results.json.

Start with optimized-timing-report.md. Earlier prepared source and debug-count results are separate immutable archives, not relabelled as optimized qualification. timing-plan.md records the intended design, while this README and optimized-timing-report.md establish completed status. No candidate structure, performance improvement, full CI or publication is claimed.
