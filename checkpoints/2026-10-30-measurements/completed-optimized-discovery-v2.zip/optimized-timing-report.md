# Optimized discovery baseline attribution

Seven measured process samples per mode, one warmup per mode, alternating mode order. All samples passed their movement/knowledge/reentry/replay checks. All 54 discovery tests also passed from this exact optimized binary. No structural candidate was implemented.

| Mode | Facts | Ascending forward median [range], ms | Ascending reentry median [range], ms |
| --- | ---: | --- | --- |
| counters-on | 16 | 2.309 [1.870, 2.840] | 0.892 [0.705, 1.099] |
| counters-on | 128 | 20.919 [17.715, 24.966] | 8.558 [7.658, 10.187] |
| counters-on | 1024 | 151.337 [143.117, 173.899] | 128.259 [119.658, 138.635] |
| counters-off | 16 | 1.981 [1.886, 2.940] | 0.776 [0.719, 1.159] |
| counters-off | 128 | 18.850 [18.180, 22.355] | 8.575 [8.076, 10.412] |
| counters-off | 1024 | 159.132 [147.692, 183.106] | 127.537 [121.104, 148.711] |
| no-cues-control | 16 | 0.110 [0.106, 0.221] | 0.079 [0.077, 0.115] |
| no-cues-control | 128 | 0.780 [0.685, 0.951] | 0.620 [0.567, 0.747] |
| no-cues-control | 1024 | 5.617 [5.192, 7.402] | 4.788 [4.646, 5.290] |

## Interpretation

The 1,024-fact counters-off forward median is 159.132 ms for initial reconciliation plus 1,025 movement actions, approximately 0.155 ms per movement when amortizing initialization. Reentry is 127.537 ms despite zero discovery-vector copies. The no-cues forward control is 5.617 ms. Discovery/cue processing is clearly material relative to bare movement in this toy, but these measurements do not isolate copying from sight/scanning/knowledge and other affected work. Copied-row growth alone does not justify chunk restructuring.

Counter-on/off ranges overlap; their difference changes sign across sizes/orders/samples. No reliable independent counter-update penalty is established. The disabled path still includes a test-only toggle check and existing scan counters, so it is not a fully instrumentation-free production binary. Counter-disabled zero counts do not mean zero actual copies.

Retain the vector; no chunk refactor, new cap, claim of a gameplay speedup or end-to-end latency claim. A later representative profile can investigate sight/discovery work before choosing a maintainable change. Reverse-ID insertion remains a separately labelled stress control; all raw reverse-order ranges are in optimized-timing-results.json.

## Exact scope

Single configured actor, fixed seed 42, narrow single-chamber corridor, concealed high-DC traps beside rather than on the walk lane, ascending or reverse feature identity assignment, and up to 32 retained prior Game snapshots. Receipts arise from ordinary Game movement/passive discovery. This is not the current Rogue generator, multi-actor combat, server transport, or a full-game workload. The no-cues control removes traps and therefore changes all cue/discovery work, not only the Vec operation.

Forward timing includes initialization, snapshot retention, movement and position assertions. Reentry includes movement and position assertions. Fixture creation, log/JSON output, readonly checks and encoded restoration are outside timing. Output was drained/captured by the test runner after phase measurement. No concurrent local Cargo build or benchmark was started during sampling. Shared-host background scheduling remains uncontrolled; the reported range captures observed variability, not a confidence interval.

Binary SHA-256: a9c428b6476b1aaf4e17de1c0c7d6c30273a98c4a8cb34ff43f701630f49097c. Rustc/cargo/profile metadata and all 2,040 unchanged source inputs are recorded in release/focused. This is optimized baseline attribution only, not candidate-versus-baseline evidence or full CI.
