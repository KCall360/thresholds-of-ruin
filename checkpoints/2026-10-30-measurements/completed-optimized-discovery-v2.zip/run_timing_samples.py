from pathlib import Path
import subprocess,os,json,hashlib,shutil,time,platform,statistics
r=Path.cwd();d=r/'.local/discovery-growth';receipt=json.loads((d/'release/focused/receipt.json').read_text());a=receipt['artifacts'][0];source=Path(a['path']);binary=d/'protected'/('release-'+source.name);shutil.copy2(source,binary);assert hashlib.sha256(binary.read_bytes()).hexdigest()==a['sha256'];print('PROTECTED',binary,a['sha256'],flush=True)
base_env=dict(os.environ)
for k in ['TOR_DISCOVERY_PROFILE_COUNTERS','TOR_DISCOVERY_PROFILE_NO_CUES','TOR_DISCOVERY_PROFILE_EXTRA_1024']:base_env.pop(k,None)
base_env['TOR_DISCOVERY_PROFILE_EXTRA_1024']='1'
modes={'counters-on':{'TOR_DISCOVERY_PROFILE_COUNTERS':'1'},'counters-off':{'TOR_DISCOVERY_PROFILE_COUNTERS':'0'},'no-cues-control':{'TOR_DISCOVERY_PROFILE_COUNTERS':'0','TOR_DISCOVERY_PROFILE_NO_CUES':'1'}}
all_rows=[];run_receipts=[]
for sample in range(-1,7):
 order=list(modes);offset=(sample+1)%3;order=order[offset:]+order[:offset]
 for mode in order:
  env={**base_env,**modes[mode]};start=time.time();p=subprocess.run([str(binary),'discovery::tests::growth_profile::','--nocapture','--test-threads=1'],env=env,capture_output=True,text=True);out=p.stdout+p.stderr;log=d/f'timing-{sample}-{mode}.log';log.write_text(out)
  rows=[json.loads(line.split('DISCOVERY_GROWTH ',1)[1])for line in out.splitlines()if 'DISCOVERY_GROWTH 'in line]
  assert p.returncode==0 and '3 passed; 0 failed' in out and len(rows)==12,(mode,sample,p.returncode,out[-3500:])
  for row in rows:
   assert row['actual_facts']==(0 if mode=='no-cues-control' else row['facts'])
   if mode=='counters-on'and row['stage']=='forward':assert row['copied_rows']=={16:239,128:9815,1024:538007}[row['facts']]
   all_rows.append({**row,'mode':mode,'sample':sample,'warmup':sample<0})
  run_receipts.append({'sample':sample,'mode':mode,'seconds':time.time()-start,'exit_code':p.returncode,'environment':{k:v for k,v in env.items()if k.startswith('TOR_DISCOVERY_PROFILE_')},'log':log.name})
  print('PASS',sample,mode,round(time.time()-start,3),flush=True)
summary=[]
for mode in modes:
 for n in [16,128,1024]:
  for order in ['ascending-id','reverse-id-stress']:
   for stage in ['forward','reentry']:
    vals=[x['elapsed_ns']for x in all_rows if not x['warmup']and(x['mode'],x['facts'],x['order'],x['stage'])==(mode,n,order,stage)]
    assert len(vals)==7
    summary.append({'mode':mode,'facts':n,'order':order,'stage':stage,'samples':7,'median_ms':statistics.median(vals)/1e6,'min_ms':min(vals)/1e6,'max_ms':max(vals)/1e6,'median_ns_per_movement':statistics.median(vals)/(n+1)})
result={'binary_sha256':a['sha256'],'source_inputs':str(d/'release/focused/inputs-after.json'),'machine':platform.platform(),'cpu_count':os.cpu_count(),'affinity':sorted(os.sched_getaffinity(0))if hasattr(os,'sched_getaffinity')else None,'samples_per_mode':7,'warmups_per_mode':1,'run_receipts':run_receipts,'rows':all_rows,'summary':summary};(d/'optimized-timing-results.json').write_text(json.dumps(result,indent=2)+'\n')
for row in summary:
 if row['order']=='ascending-id':print('SUMMARY',json.dumps(row),flush=True)
